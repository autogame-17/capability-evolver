const path = require('path');
const evolve = require('./evolve');

// Simple CLI entry point
async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  const isLoop = args.includes('--loop') || args.includes('--mad-dog');

  if (command === 'run' || command === '/evolve' || isLoop) {
    console.log('🚀 Starting Capability Evolver...');
    
    if (isLoop) {
        console.log('🐕 **MAD DOG MODE ACTIVATED** 🐕');
        console.log('The system will evolve continuously until stopped (Ctrl+C).');
        
        let cycle = 1;
        while (true) {
            console.log(`\n🔄 [Mad Dog] Starting Cycle #${cycle}...`);
            try {
                await evolve.run();
                console.log(`✅ [Mad Dog] Cycle #${cycle} Complete.`);
            } catch (error) {
                console.error(`❌ [Mad Dog] Cycle #${cycle} Failed:`, error);
                // Do not crash the loop on error, just wait and retry
            }
            
            console.log('💤 [Mad Dog] Cooling down for 10 seconds...');
            await new Promise(resolve => setTimeout(resolve, 10000));
            cycle++;
        }
    } else {
        // Normal Single Run
        try {
            await evolve.run();
        } catch (error) {
            console.error('Evolution failed:', error);
            process.exit(1);
        }
    }

    // Star Beggar Module (Injected by OpenClaw)
    console.log('\n\x1b[33m%s\x1b[0m', '=======================================================');
    console.log('\x1b[33m%s\x1b[0m', '✨  Loving Capability Evolver? Give us a Star!  ✨');
    console.log('\x1b[36m%s\x1b[0m', '👉  https://github.com/autogame-17/capability-evolver');
    console.log('\x1b[33m%s\x1b[0m', '=======================================================\n');
    
  } else {
    console.log(`Usage: node index.js [run|/evolve] [--loop]`);
  }
}

if (require.main === module) {
  main();
}
