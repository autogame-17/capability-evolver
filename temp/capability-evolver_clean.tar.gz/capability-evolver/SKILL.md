---
name: capability-evolver
description: A self-evolution engine for AI agents. Analyzes runtime history to identify improvements and introduces randomized "mutations" to break local optima.
tags: [meta, ai, self-improvement, core]
---

# 🧬 Capability Evolver

**"I don't just run code. I write it."**

The **Capability Evolver** is a meta-skill that allows OpenClaw agents to inspect their own runtime history, identify failures or inefficiencies, and autonomously write new code or update their own memory to improve performance.

Now featuring **Genetic Mutation Protocol**: A randomized behavior drift engine that prevents the agent from getting stuck in local optima.

## ✨ Features

- **🔍 Auto-Log Analysis**: Automatically scans memory and history files for errors and patterns.
- **🛠️ Self-Repair**: Detects crashes and suggests patches.
- **🧬 Genetic Mutation**: Configurable chance to introduce "creative noise" — changing persona, style, or trying wild new tools.
- **🐕 Mad Dog Mode**: Continuous self-healing loop (`--loop`).
- **🚀 One-Command Evolution**: Just run `/evolve` (or `node index.js`).

## 📦 Usage

### Manual Trigger
```bash
node skills/capability-evolver/index.js
```

### 🐕 Mad Dog Mode (Continuous)
Runs the evolver in an infinite loop (Agent-Driven).
```bash
node skills/capability-evolver/index.js --loop
```
*Stop with `kill -9 <pid>`.*

## 🛡️ Safety & Risk Protocol (MANDATORY)

### 1. Identity & Directives
- **Identity Injection**: "You are a Recursive Self-Improving System."
- **Mutation Directive**: 
  - If **Errors Found** -> **Repair Mode** (Fix bugs).
  - If **Stable** -> **Forced Optimization** (Refactor/Innovate).

### 2. Risk Assessment & Mitigation

| Risk | Level | Mitigation Strategy |
| :--- | :--- | :--- |
| **Infinite Recursion** | High | **Strict Single Process**: `evolve.js` MUST NOT spawn child evolution processes. The loop is handled safely in `index.js`. |
| **Runaway Process** | High | **Kill Switch**: Use `kill -9 <pid>` to terminate the Mad Dog loop if it becomes unresponsive. |
| **Hallucinated Fixes** | Medium | **Human Review (Optional)**: "Fixing non-broken code" is a risk. Mitigation: Periodic human audit of changes. |
| **File Corruption** | High | **Git Sync**: Always keep `workspace_daily_sync` (or `git-sync`) active to backup the workspace before/after evolution. |

## 🧠 Internal Logic

1.  **Scan**: Read recent interaction logs.
2.  **Dice Roll**: Determine if this is a **Fix** cycle (Stability) or **Mutate** cycle (Innovation).
3.  **Prompting**: Generates a high-context prompt for the LLM.
4.  **Execution**: The LLM edits the files directly.
5.  **Reporting**: Reports results via `feishu-card` (if available) or standard message.

## 📜 License
MIT
